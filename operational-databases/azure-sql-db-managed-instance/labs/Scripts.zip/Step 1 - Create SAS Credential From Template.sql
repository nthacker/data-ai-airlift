/* This is script that generates SAS credential to Azure Storage Account created for this Lab

You will need to create this SAS credential BOTH on source SQL Server and destination Managed Instance

This file represent QUERY TEMPLATE. Copy its content into a new query window and then press Ctrl + Shift + M to open template parameter form.
DO NOT INCLUDE leading '?' in <SAS SECRET>!

*/

IF EXISTS (select * from sys.credentials where name = N'<Azure Blob URL, , >')
	DROP CREDENTIAL [<Azure Blob URL, , >] -- Example: [https://mystorage.blob.core.windows.net/mysqlbackups];

	CREATE CREDENTIAL [<Azure Blob URL, , >] 
	WITH IDENTITY = 'SHARED ACCESS SIGNATURE'  
	,SECRET = '<SAS secret, , >'; 