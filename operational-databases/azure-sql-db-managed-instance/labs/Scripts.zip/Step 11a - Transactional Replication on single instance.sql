-- Print out system details for records
use master
go
print 'SERVERPROPERTY(''ServerName'') = ' + IsNull(cast(SERVERPROPERTY('ServerName') as sysname),'<null>') + ', @@SERVERNAME = ' + isnull(@@SERVERNAME,'<null>')
declare @srv sysname = (select top 1 concat('server_id: ',server_id,', name: ',isnull(name,'<null>'),', data_source: ',isnull(data_source,'<null>')) from sys.servers order by server_id)
declare @product_version sysname = (SELECT max(replace(product_version,':','.')) FROM sys.dm_os_loaded_modules where name like '%\sqlservr.exe')
print 'first row from sys.servers = [' + isnull(@srv,'<null>') + ']'
print concat('EditionId = ', convert(nvarchar, cast(cast(serverproperty('EditionId') as int) as binary(4)),1),
      ', EngineEdition = ', cast(serverproperty('EngineEdition') as int),
      ', @@MICROSOFTVERSION = ', convert(nvarchar, cast(@@MICROSOFTVERSION as binary(4)),1),
	  ' [' , @@MICROSOFTVERSION/0x1000000, '.', @@MICROSOFTVERSION / 0x10000 & 0xff, '.', @@MICROSOFTVERSION & 0xffff, ']',
	  ', SQL Server Product Version = ', @product_version)
print @@VERSION
go
--
-- !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!! --
-- !!! SPECIFY THE RIGHT MI FQDN NAME, USER, PASSWORD AND AZURE FILE STORAGE DETAILS IN A QUERY BELOW !!! --
-- !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!! --
drop table if exists [master].[dbo].[CL_FQDN]
select  [name] = @@ServerName,
		[user] = N'<SQL User, , >',
		[password] = N'<Password, , >',
		[working_directory] = N'\\<Azure Blob Store, , >.file.core.windows.net\replication', -- you need to allocate file storage share within general purpose storage account
		[storage_connection_string] = N'<Storage connection string, , >', -- this can be obtained through Azure Portal at: Storage -> Settings -> Access keys
		{fn now()} as start, {fn now()} as clean, {fn now()} as dist, {fn now()} as data, {fn now()} as meta, {fn now()} as finish into [master].[dbo].[CL_FQDN]
declare @cl_fqdn sysname = (select name from [master].[dbo].[CL_FQDN])
print 'Saved CL FQDN to master DB: ' + @cl_fqdn
go
select * from master.dbo.CL_FQDN
--
-- Enabling XEvent Session to see in a live session under: Management -> Extendend Events -> Sessions -> Replication -> (Right mouse click) -> Watch Live Data
IF EXISTS(SELECT * FROM sys.server_event_sessions WHERE name='Replication') DROP EVENT SESSION [Replication] ON SERVER
GO
CREATE EVENT SESSION [Replication] ON SERVER
	ADD EVENT sqlserver.repl_distribution_status,
	ADD EVENT sqlserver.repl_logreader_status,
	ADD EVENT sqlserver.repl_snapshot_status
	WITH (STARTUP_STATE=ON)
GO
ALTER EVENT SESSION [Replication] ON SERVER STATE = start
GO
--
-- clean up from a previous run if applicable
USE [master]
IF EXISTS (SELECT * FROM sys.databases WHERE name in (N'PubDB',N'SubDB',N'distribution')) 
BEGIN
	-- Shutdown Log Reader Agent --
	DECLARE @job_id uniqueidentifier
	SELECT @job_id = Job.job_id FROM msdb.dbo.sysjobactivity AS Act INNER JOIN msdb.dbo.sysjobs_view AS Job ON Act.job_id = Job.job_id INNER JOIN msdb.dbo.syscategories AS Cat ON Job.category_id = Cat.category_id WHERE Job.name LIKE '%-PubDB-%' AND Cat.name = N'REPL-LogReader' AND Act.stop_execution_date is NULL
	IF @job_id IS NOT NULL EXEC msdb.dbo.sp_stop_job @job_id = @job_id ELSE PRINT N'There is no running Log Reader Job identified' 
	DECLARE @cnt int = 0
	WHILE EXISTS (SELECT * FROM msdb.dbo.sysjobactivity AS Act INNER JOIN msdb.dbo.sysjobs_view AS Job ON Act.job_id = Job.job_id INNER JOIN msdb.dbo.syscategories AS Cat ON Job.category_id = Cat.category_id WHERE Job.name LIKE '%-PubDB-%' AND Cat.name = N'REPL-LogReader' AND Act.stop_execution_date is NULL AND @cnt < 3*60) 
	BEGIN
		WAITFOR DELAY '00:00:01'
		SET @cnt = @cnt + 1
	END
	-- Make sure noone uses distribution DB --
	DECLARE  @spid int, @DistDropped int = 0
	WHILE EXISTS (SELECT spid FROM sys.sysprocesses WHERE dbid = DB_ID('distribution') and spid > 50) BEGIN
		SELECT TOP 1 @spid = spid FROM sys.sysprocesses WHERE dbid = DB_ID('distribution') and spid > 50
		BEGIN TRY EXEC ('kill ' + @spid) END TRY BEGIN CATCH /* if the kill failed, there is nothing that we can do since the session could have been killed already. */ END CATCH
	END
	-- Disable Replication and Drop DBs
	exec [PubDB].sys.sp_replflush
	declare @cl_fqdn sysname = (select name from [master].[dbo].[CL_FQDN])
	exec [PubDB].sys.sp_dropsubscription @publication = N'PubDB_Publication', @article = N'all', @subscriber = @cl_fqdn
	exec [PubDB].sys.sp_droppublication @publication = N'PubDB_Publication'
	exec sp_removedbreplication @dbname = N'PubDB'
	-- Dropping DBs
	IF EXISTS (SELECT name FROM sys.databases WHERE name = N'SubDB') BEGIN
		EXEC msdb.dbo.sp_delete_database_backuphistory @database_name = N'SubDB'
		DROP DATABASE [SubDB]
	END
	IF EXISTS (SELECT name FROM sys.databases WHERE name = N'PubDB') BEGIN
		EXEC msdb.dbo.sp_delete_database_backuphistory @database_name = N'PubDB'
		DROP DATABASE [PubDB]
	END
		IF EXISTS (SELECT * FROM sysservers WHERE dist = 1) 
		BEGIN
		exec sp_dropdistributor @no_checks = 1, @ignore_distributor = 1
		END

END
update [master].[dbo].[CL_FQDN] set clean = {fn now()}
declare @sec sysname = (select DATEDIFF(SECOND,start,clean) from [master].[dbo].[CL_FQDN])
print concat('Clean up time: ', @sec, ' sec(s)')
GO
--
-- enable distribution
-- This operation might fail, just ignore the error (it still does its job)
IF NOT EXISTS (SELECT * FROM sysservers WHERE dist = 1) BEGIN TRY
	use master
	exec sp_adddistributor @distributor = @@ServerName
END TRY BEGIN CATCH
	declare @error nvarchar(max) = 'Warning [' + cast(ERROR_NUMBER() as nvarchar) + ']: ' + ERROR_MESSAGE()
	RAISERROR(@error,0,0)
END CATCH
GO
IF NOT EXISTS (SELECT * FROM sysservers WHERE dist = 1) OR NOT EXISTS (SELECT name FROM sys.databases WHERE name = N'distribution')
BEGIN
	declare @cl_fqdn sysname = (select name from [master].[dbo].[CL_FQDN]), @user sysname = (select [user] from [master].[dbo].[CL_FQDN]), @password sysname = (select [password] from [master].[dbo].[CL_FQDN])
	declare @working_directory nvarchar(255) = (select working_directory from [master].[dbo].[CL_FQDN])
	declare @storage_connection_string nvarchar(779) = (select storage_connection_string from [master].[dbo].[CL_FQDN])
	use master
	exec sp_adddistributiondb @database = N'distribution'
	exec sp_adddistpublisher @publisher = @@ServerName, @distribution_db = N'distribution', @security_mode = 0, @login = @user, @password = @password,
							 @working_directory = @working_directory, @storage_connection_string = @storage_connection_string
END
GO
--
-- let's start test itmer
update [master].[dbo].[CL_FQDN] set dist = {fn now()}
declare @sec sysname = (select DATEDIFF(SECOND,clean,dist) from [master].[dbo].[CL_FQDN])
print concat('Distribution set up time: ', @sec, ' sec(s)')
GO
--
-- create DB from scratch
CREATE DATABASE [PubDB]
CREATE DATABASE [SubDB]
GO
--
USE [PubDB]
-- Create Table participating in Replication 
CREATE TABLE [dbo].[Repl_Table1] (
       [Order_ID] [int] NOT NULL,
       [Customer_ID] [int] NULL,
       [Total_Amount] [decimal](18, 0) NULL,
       [Year] [int] NOT NULL,
       PRIMARY KEY CLUSTERED ( [Order_ID],[Year] ASC )
)
GO
--
insert into [PubDB].[dbo].[Repl_Table1] values (1,2,3,4)
--
update [master].[dbo].[CL_FQDN] set data = {fn now()}
declare @sec sysname = (select DATEDIFF(SECOND,dist,data) from [master].[dbo].[CL_FQDN])
print concat('Initial data set up time: ', @sec, ' sec(s)')
GO
--
use [PubDB]
exec sp_replicationdboption @dbname = N'PubDB', @optname = N'publish', @value = N'true'
GO
--
-- Adding the transactional publication
declare @cl_fqdn sysname = (select name from [master].[dbo].[CL_FQDN]), @user sysname = (select [user] from [master].[dbo].[CL_FQDN]), @password sysname = (select [password] from [master].[dbo].[CL_FQDN])
declare @job_login sysname = @user, @job_password sysname = @password
use [PubDB]
exec sp_addpublication
	@publication = N'PubDB_Publication',
	@description = N'Transactional publication of database ''PubDB'' from Local MI Publisher.',
	@sync_method = N'concurrent',
	@retention = 0,
	@allow_push = N'true',
	@allow_pull = N'true',
	@allow_anonymous = N'true',
	@snapshot_in_defaultfolder = N'true',
	@compress_snapshot = N'false',
	@allow_subscription_copy = N'false',
	@repl_freq = N'continuous',
	@status = N'active',
	@independent_agent = N'true',
	@immediate_sync = N'true',
	@allow_sync_tran = N'false',
	@autogen_sync_procs = N'false',
	@allow_queued_tran = N'false',
	@allow_dts = N'false',
	@replicate_ddl = 1,
	@allow_initialize_from_backup = N'false',
	@enabled_for_p2p = N'false',
	@enabled_for_het_sub = N'false'
-- apply login timeout setting to replication jobs unless it was already provided (this is a temporary workaround to minimize possible impact if login takes longer)
update msdb..sysjobsteps set command = command + N' -LoginTimeout 150' where subsystem in ('Distribution','LogReader','Snapshot') and command not like '%-LoginTimeout %'
--
exec sp_changelogreader_agent
	@publisher_security_mode = 0,
	@publisher_login = @user,
	@publisher_password = @password,
	@job_login = @job_login,
	@job_password = @job_password
exec sp_addpublication_snapshot
	@publication = N'PubDB_Publication',
	@frequency_type = 1,
	@publisher_security_mode = 0,
	@publisher_login = @user,
	@publisher_password = @password,
	@job_login = @job_login,
	@job_password = @job_password
-- apply login timeout setting to replication jobs unless it was already provided (this is a temporary workaround to minimize possible impact if login takes longer)
update msdb..sysjobsteps set command = command + N' -LoginTimeout 150' where subsystem in ('Distribution','LogReader','Snapshot') and command not like '%-LoginTimeout %'
--
exec sp_addarticle
	@publication = N'PubDB_Publication',
	@article = N'Repl_Table1',
	@source_owner = N'dbo',
	@source_object = N'Repl_Table1',
	@type = N'logbased',
	@description = null,
	@creation_script = null,
	@pre_creation_cmd = N'drop',
	@schema_option = 0x000000000803509F,
	@identityrangemanagementoption = N'manual',
	@destination_table = N'Repl_Table1',
	@destination_owner = N'dbo',
	@vertical_partition = N'false',
	@ins_cmd = N'CALL sp_MSins_dboRepl_Table1',
	@del_cmd = N'CALL sp_MSdel_dboRepl_Table1',
	@upd_cmd = N'SCALL sp_MSupd_dboRepl_Table1'
-- And create a subscription

declare @cl_fqdn sysname = (select name from [master].[dbo].[CL_FQDN]), @user sysname = (select [user] from [master].[dbo].[CL_FQDN]), @password sysname = (select [password] from [master].[dbo].[CL_FQDN])
declare @job_login sysname = @user, @job_password sysname = @password

exec sp_addsubscription
	@publication = N'PubDB_Publication',
	@subscriber = @cl_fqdn,
	@destination_db = N'SubDB',
	@subscription_type = N'Push',
	@sync_type = N'automatic',
	@article = N'all',
	@update_mode = N'read only',
	@subscriber_type = 0
exec sp_addpushsubscription_agent
	@publication = N'PubDB_Publication',
	@subscriber = @cl_fqdn,
	@subscriber_db = N'SubDB',
	@subscriber_security_mode = 0,
	@subscriber_login = @user,
	@subscriber_password = @password,
	@job_login = @job_login,
	@job_password = @job_password
-- apply login timeout setting to replication jobs unless it was already provided (this is a temporary workaround to minimize possible impact if login takes longer)
update msdb..sysjobsteps set command = command + N' -LoginTimeout 150' where subsystem in ('Distribution','LogReader','Snapshot') and command not like '%-LoginTimeout %'
GO
--
update [master].[dbo].[CL_FQDN] set meta = {fn now()}
declare @sec sysname = (select DATEDIFF(SECOND,data,meta) from [master].[dbo].[CL_FQDN])
print concat('Replication metadata configuration time: ', @sec, ' sec(s)')
GO
--
-- Now start sanpshot agent and wait for max 3*60 seconds to complete job
USE [PubDB]
EXEC sp_startpublication_snapshot @publication = N'PubDB_Publication'
GO
WAITFOR DELAY '00:00:01'
DECLARE @cnt int = 0
WHILE EXISTS (SELECT * FROM msdb.dbo.sysjobactivity AS Act INNER JOIN msdb.dbo.sysjobs_view AS Job ON Act.job_id = Job.job_id INNER JOIN msdb.dbo.syscategories AS Cat ON Job.category_id = Cat.category_id WHERE Job.name LIKE '%-PubDB-%' AND Cat.name = N'REPL-Snapshot' AND Act.stop_execution_date is NULL AND @cnt < 3*60) BEGIN
    WAITFOR DELAY '00:00:01'
    SET @cnt = @cnt + 1
END
GO
--
-- Wait for distribution agent to replicate schema and data within max 3*60 seconds
print 'Let''s wait a while for Distribution agent to deliver snapshot...'
WAITFOR DELAY '00:00:01'
DECLARE @cnt int = 0, @rows int
WHILE (OBJECT_ID('SubDB.dbo.Repl_Table1') IS NULL OR IsNull(@rows,0) = 0) AND @cnt < 3 * 60 BEGIN
    WAITFOR DELAY '00:00:01'
    IF OBJECT_ID('SubDB.dbo.Repl_Table1') IS NOT NULL SELECT @rows = count(*) FROM SubDB.dbo.Repl_Table1
	IF @rows IS NOT NULL print concat('Found ', @rows, ' row(s) in SubDB table, looks like snapshot was applied')
    SET @cnt = @cnt + 1
END
GO
--
-- This should return two rows if everything was OK or fail otherwise
select 'PubDB (initial)' as DB, * from PubDB.dbo.Repl_Table1
union
select 'SubDB (initial)' as DB, * from SubDB.dbo.Repl_Table1
go
if @@rowcount <> 2 raiserror(N'Select should return two rows!', 16, 1)
go
--
-- run this after initial sync to test following update
print 'Applying additional changes...'
insert into [PubDB].[dbo].[Repl_Table1] values (-1,-2,-3,-4)
go
update [PubDB].[dbo].[Repl_Table1] set [Year] = -[Year] where [Year] < 0 and [Order_ID] < 0
go
delete from [PubDB].[dbo].[Repl_Table1] where [Year] > 0 and [Order_ID] > 0
go
--
-- Allowing some time for a log reader and distribution to process changes...
WAITFOR DELAY '00:00:15'
GO
--
-- post check
select 'PubDB (updated)' as DB, * from PubDB.dbo.Repl_Table1
union
select 'SubDB (updated)' as DB, * from SubDB.dbo.Repl_Table1
go
if @@rowcount <> 2 raiserror(N'Select should return two rows after delivering all changes!', 16, 1)
go
if (select min(Order_ID) from SubDB.dbo.Repl_Table1) > 0 raiserror(N'Order_ID should turn to negative in SubDB table!', 16, 1)
go
--
update [master].[dbo].[CL_FQDN] set finish = {fn now()}
declare @sec sysname = (select DATEDIFF(SECOND,meta,finish) from [master].[dbo].[CL_FQDN])
print concat('Replication initialisation and data sync up time: ', @sec, ' sec(s)')
go
--
/*
-- check Agents history for troubleshooting if necessary
select * from distribution.dbo.MSlogreader_history
select * from distribution.dbo.MSsnapshot_history
select * from distribution.dbo.MSdistribution_history
go
*/
--
declare @sec sysname = (select DATEDIFF(SECOND,start,finish) from [master].[dbo].[CL_FQDN])
print concat('Total test duration time: ', @sec, ' sec(s)')
go
--
-- show test execution summary
select start, DATEDIFF(SECOND,start,clean) [cleanup, sec], DATEDIFF(SECOND,clean,dist) [dist DB, sec], DATEDIFF(SECOND,dist,data) [data init, sec], DATEDIFF(SECOND,data,meta) [repl init, sec], DATEDIFF(SECOND,meta,finish) [repl sync, sec], finish, concat(DATEDIFF(SECOND,start,finish),' sec(s) [ ',CAST(DATEDIFF(SECOND,start,finish)/60.0 as NUMERIC(10,1)),' min(s) ]') [total] from [master].[dbo].[CL_FQDN]
go
