--Do this on MI instance
--Create credential for Restore from URL
IF EXISTS (select * from sys.credentials where name = N'<Azure Blob URL, , >/backups')
	DROP CREDENTIAL [<Azure Blob URL, , >/backups] -- Example: [];

	CREATE CREDENTIAL [<Azure Blob URL, , >/backups] 
	WITH IDENTITY = 'SHARED ACCESS SIGNATURE'  
	,SECRET = '<SAS secret, , >'; 


--Can i read the contents of the backup?
--RESTORE FILELISTONLY
RESTORE FILELISTONLY   
FROM URL = N'<Azure Blob URL, , >/backups/Adventureworksv2012withTDE.bak'

--Restore from URL
RESTORE DATABASE Adventureworks2012withTDE  
FROM URL = N'<Azure Blob URL, , >/backups/Adventureworksv2012withTDE.bak'


--
-- Verify that the database is encrypted
USE Adventureworks2012withTDE
SELECT
	db.name,
	db.is_encrypted,
	dek.encryption_state,
	dek.key_algorithm,
	dek.key_length
FROM sys.dm_database_encryption_keys dek
INNER JOIN sys.databases db ON db.database_id = dek.database_id
go