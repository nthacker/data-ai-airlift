/*
	This script perform one-off full backup of your application databases to Azure blob storage account that you will use for the migration.
	Execute this script on SQL on VM only!

	This file represent QUERY TEMPLATE. Copy its content into a new query window and then press Ctrl + Shift + M to open template parameter form.
	DO NOT END <Azure Blob URL> parameter with '/' !
*/

USE MASTER;
GO

BACKUP DATABASE TenantDataDB   
TO URL = N'<Azure Blob URL, , >/TenantDataDBv2012.bak'
WITH FORMAT, INIT

GO

BACKUP DATABASE SharedMasterDataDB   
TO URL = N'<Azure Blob URL, , >/SharedMasterDataDBv2012.bak'
WITH FORMAT, INIT

GO

BACKUP DATABASE LocalMasterDataDB   
TO URL = N'<Azure Blob URL, , >/LocalMasterDataDBv2012.bak'
WITH FORMAT, INIT

GO

