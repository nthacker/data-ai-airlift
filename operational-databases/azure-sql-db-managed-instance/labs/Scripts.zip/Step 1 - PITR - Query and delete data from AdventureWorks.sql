USE [AdventureWorks2012];

GO


/*List all tables */
SELECT t.name as TableName, s.name as SchemaName FROM sys.tables t
join sys.schemas s on t.schema_id = s.schema_id
order by t.[Name]



SELECT COUNT(*) from  Production.TransactionHistory

/*DELETE 38442 rows */
DELETE FROM Production.TransactionHistory
where TransactionID > 175000


SELECT COUNT(*) from  Production.TransactionHistory --75001

/***************************************
	STOP Query execution here, go to Azure Portal, run point in time restore and then resume execution
	Check instructions for details
****************************************/

/*Enter here name of the database you have recovered*/
USE [AdventureWorks2012_Recovered]
GO

/*List all tables */
SELECT t.name as TableName, s.name as SchemaName FROM sys.tables t
join sys.schemas s on t.schema_id = s.schema_id
order by t.[Name]


SELECT COUNT(*) from  Production.TransactionHistory --113443
