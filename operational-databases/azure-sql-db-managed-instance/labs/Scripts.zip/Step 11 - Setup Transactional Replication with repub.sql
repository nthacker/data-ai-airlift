--setup dist using UI
--Modify logreader and snapshot agent to authenticate using SQL auth
--Modify publisher to use Azure Files to write snapshot files to

declare @user sysname = '<SQL User, , >'
declare @password sysname = '<Password, , >'
declare @job_login sysname = @user
declare @job_password sysname = @password

declare @publication sysname = 'AWRepubPerson'

exec sp_changelogreader_agent @publisher_security_mode = 0, @publisher_login = @user, @publisher_password = @password, @job_login = @job_login, @job_password = @job_password
exec sp_changepublication_snapshot @publication = @publication, @frequency_type = 1, @publisher_security_mode = 0, @publisher_login = @user, @publisher_password = @password, @job_login = @job_login, @job_password = @job_password


exec sp_changesubscription @publication = @publication, @article = N'all', @subscriber = @@ServerName, @destination_db = N'SubDB', @property = N'distrib_job_login', @value = @job_login
--exec sp_changesubscription @publication = @publication, @article = N'all', @subscriber = @@ServerName, @destination_db = N'SubDB', @property = N'distrib_job_password',@value = @job_password

--Set storage and working directory to Azure files
exec sp_changedistpublisher @publisher = @@ServerName, @property = N'storage_connection_string', @value = N'<Storage connection string, , >'

exec sp_changedistpublisher @publisher = @@ServerName, @property = N'working_directory', @value = N'\\<Azure Blob Storage Account, , >.file.core.windows.net\replication'


--add MI subscriber, create a subscription to second MI and setup push subscription

declare @publication sysname = 'AWRepub_Person'
EXEC sp_addsubscription @publication = @publication,
             @subscriber = '<Subscriber FQDN, , >',
             @destination_db = N'Adventureworks2012Sub',
             @subscription_type = N'Push'



EXEC sp_addpushsubscription_agent @publication = @publication,
             @subscriber = '<Subscriber FQDN, , >',
             @subscriber_db = N'Adventureworks2012Sub',
             @subscriber_security_mode = 0,
             @subscriber_login = @user,
             @subscriber_password = @password,
             @job_login =@job_login, 
             @job_password = @job_password

