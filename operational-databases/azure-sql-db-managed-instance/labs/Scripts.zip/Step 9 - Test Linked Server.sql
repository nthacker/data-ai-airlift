/*
	This query demonstrates Linked server feature.
	Execute this script on Managed Instance only once linked server is created

*/

SELECT * from <SQL VM private IP address, , >.[LocalMasterDataDB].[dbo].[Users]