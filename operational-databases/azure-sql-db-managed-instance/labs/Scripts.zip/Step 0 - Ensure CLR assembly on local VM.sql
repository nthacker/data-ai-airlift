ALTER DATABASE [TenantDataDb] SET TRUSTWORTHY ON;


USE [TenantDataDb]
GO

EXEC sp_changedbowner 'sa'
