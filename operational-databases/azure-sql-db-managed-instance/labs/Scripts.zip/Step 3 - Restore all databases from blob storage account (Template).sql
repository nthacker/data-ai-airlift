/*

	This script perform full restore of your application databases from Azure blob storage account that you will use for the migration.
	Execute this script on Managed Instance only!

	This file represent QUERY TEMPLATE. Copy its content into a new query window and then press Ctrl + Shift + M to open template parameter form.
	DO NOT END <Azure Blob URL> parameter with '/' !

*/

USE master;
GO

-------
IF EXISTS (select * from sys.databases where name = 'LocalMasterDataDB')
	DROP DATABASE LocalMasterDataDB
	
GO
RESTORE DATABASE LocalMasterDataDB  
FROM URL = N'<Azure Blob URL, , >/LocalMasterDataDBv2012.bak'

GO
--------
IF EXISTS (select * from sys.databases where name = 'SharedMasterDataDB')
	DROP DATABASE SharedMasterDataDB
	
GO
RESTORE DATABASE SharedMasterDataDB  
FROM URL = N'<Azure Blob URL, , >/SharedMasterDataDBv2012.bak'

GO
---------
IF EXISTS (select * from sys.databases where name = 'TenantDataDB')
	DROP DATABASE TenantDataDB
GO
RESTORE DATABASE TenantDataDB  
FROM URL = N'<Azure Blob URL, , >/TenantDataDBv2012.bak'

GO

SELECT name, compatibility_level FROM sys.databases