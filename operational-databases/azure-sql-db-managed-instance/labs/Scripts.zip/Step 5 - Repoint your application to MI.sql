/*

Now it's time to re-point your application to MI (go to Settings tab and populate Server name and Password)

Before doing that, execute query below to get familiar with Managed Instance metadata.
Copy ServerName column and paste its value into the corresponing field of the Settings tab of the application

Alos, note that Managed Instance is:
	1) uniquely identifiable with EngineEdition = 8
	2) It is running latest SQL Engine version (MSFTVersionMajor = 15) 

*/

SELECT @@SERVERNAME as ServerName,
@@VERSION as [Version], SERVERPROPERTY ('Edition') as [Edition], 
SERVERPROPERTY('EngineEdition') as [EngineEdition], 
@@MICROSOFTVERSION / POWER(2, 24) as MSFTVersioMajor