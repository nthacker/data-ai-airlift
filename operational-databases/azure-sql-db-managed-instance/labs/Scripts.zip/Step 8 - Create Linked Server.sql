/*

	This script creates linked server from SQL MI to SQL on VM, enabling hybrid scenarios.
	Execute this script on Managed Instance only!
	Provide PRIVATE IP ADDRESS for SQL on VM as communication goes withing the same VNet.

	This file represent QUERY TEMPLATE. 
	Copy its content into a new query window and then press Ctrl + Shift + M to open template parameter form.
	
*/

USE [master]
GO

EXEC master.dbo.sp_addlinkedserver @server = N'<SQL VM private IP address, , >', @srvproduct=N'SQL Server'
 /* For security reasons the linked server remote logins password is changed with ######## */
EXEC master.dbo.sp_addlinkedsrvlogin @rmtsrvname=N'<SQL VM private IP address, , >',@useself=N'False',@locallogin=NULL,@rmtuser=N'<Sql login on SQL VM, , >',@rmtpassword='<Password for sql login, , >'
GO

EXEC master.dbo.sp_serveroption @server=N'<SQL VM private IP address, , >', @optname=N'collation compatible', @optvalue=N'false'
GO

EXEC master.dbo.sp_serveroption @server=N'<SQL VM private IP address, , >', @optname=N'data access', @optvalue=N'true'
GO

EXEC master.dbo.sp_serveroption @server=N'<SQL VM private IP address, , >', @optname=N'dist', @optvalue=N'false'
GO

EXEC master.dbo.sp_serveroption @server=N'<SQL VM private IP address, , >', @optname=N'pub', @optvalue=N'false'
GO

EXEC master.dbo.sp_serveroption @server=N'<SQL VM private IP address, , >', @optname=N'rpc', @optvalue=N'false'
GO

EXEC master.dbo.sp_serveroption @server=N'<SQL VM private IP address, , >', @optname=N'rpc out', @optvalue=N'false'
GO

EXEC master.dbo.sp_serveroption @server=N'<SQL VM private IP address, , >', @optname=N'sub', @optvalue=N'false'
GO

EXEC master.dbo.sp_serveroption @server=N'<SQL VM private IP address, , >', @optname=N'connect timeout', @optvalue=N'0'
GO

EXEC master.dbo.sp_serveroption @server=N'<SQL VM private IP address, , >', @optname=N'collation name', @optvalue=null
GO

EXEC master.dbo.sp_serveroption @server=N'<SQL VM private IP address, , >', @optname=N'lazy schema validation', @optvalue=N'false'
GO

EXEC master.dbo.sp_serveroption @server=N'<SQL VM private IP address, , >', @optname=N'query timeout', @optvalue=N'0'
GO

EXEC master.dbo.sp_serveroption @server=N'<SQL VM private IP address, , >', @optname=N'use remote collation', @optvalue=N'true'
GO

EXEC master.dbo.sp_serveroption @server=N'<SQL VM private IP address, , >', @optname=N'remote proc transaction promotion', @optvalue=N'true'
GO


