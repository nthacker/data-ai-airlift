--On source on-premises SQL Server, create a master key, DEK certificate and back it up:

USE master;  
GO  
CREATE MASTER KEY ENCRYPTION BY PASSWORD = '<Password, , >';  
go  
CREATE CERTIFICATE TDEDemoCertforMI WITH SUBJECT = 'TDEDemo DEK Certificate';  
go 
 
USE AdventureWorks2012;  
GO  

CREATE DATABASE ENCRYPTION KEY  
WITH ALGORITHM = AES_128  
ENCRYPTION BY SERVER CERTIFICATE TDEDemoCertforMI;  
GO  
ALTER DATABASE AdventureWorks2012 
SET ENCRYPTION ON;  
GO

use master
go
SELECT db.name as [database_name], cer.name as [certificate_name], cer.*, dek.*
FROM sys.dm_database_encryption_keys dek
LEFT JOIN sys.certificates cer
ON dek.encryptor_thumbprint = cer.thumbprint
INNER JOIN sys.databases db
ON dek.database_id = db.database_id
WHERE dek.encryption_state = 3


USE master
GO

BACKUP CERTIFICATE TDEDemoCertforMI
TO FILE = 'C:\Demo Materials\TDEDemoCertforMI.cer'
WITH PRIVATE KEY (
  FILE = 'C:\Demo Materials\TDEDemoCertforMI.pvk',
  ENCRYPTION BY PASSWORD = '<Password, , >'
)


--Create credential for Backup to URL storage blob
IF EXISTS (select * from sys.credentials where name = N'<Azure Blob URL, , >/backups')
DROP CREDENTIAL [<Azure Blob URL, , >/backups]
	-- Example: [https://bonovasqlbackups.blob.core.windows.net/mysqlbackups];

CREATE CREDENTIAL [<Azure Blob URL, , >/backups] 
WITH IDENTITY = 'sqldbmistorage'  
,SECRET = '<Access Key, , >'; 

--Backup source database that has TDE enabled	
BACKUP DATABASE Adventureworks2012  
TO URL = N'<Azure Blob URL, , >/backups/Adventureworksv2012withTDE.bak'
WITH CREDENTIAL='<Azure Blob URL, , >/backups', FORMAT, INIT, STATS=5

--Do this on MI instance
--Create credential for Restore from URL
IF EXISTS (select * from sys.credentials where name = N'<Azure Blob URL, , >/backups')
	DROP CREDENTIAL [<Azure Blob URL, , >/backups] -- Example: [];

	CREATE CREDENTIAL [<Azure Blob URL, , >/backups] 
	WITH IDENTITY = 'SHARED ACCESS SIGNATURE'  
	,SECRET = '<Access Key, , >'; 


--Can i read the contents of the backup?
--RESTORE FILELISTONLY
RESTORE FILELISTONLY   
FROM URL = N'<Azure Blob URL, , >/backups/Adventureworksv2012withTDE.bak'

--Restore from URL
RESTORE DATABASE Adventureworks2012withTDE  
FROM URL = N'<Azure Blob URL, , >/backups/Adventureworksv2012withTDE.bak'

--Upload cert using "C:\Demo Materials\Scripts\Deployment\UploadTDECerttoMI.ps1" script.
--Show the uploaded cert in activity log for the MI instance in the portal.
--Repeat above restore commands, it should work now

--Check encryption settings for the database
USE master
go
SELECT db.name as [database_name], cer.name as [certificate_name], cer.*, dek.*
FROM sys.dm_database_encryption_keys dek
LEFT JOIN sys.certificates cer
ON dek.encryptor_thumbprint = cer.thumbprint
INNER JOIN sys.databases db
ON dek.database_id = db.database_id
WHERE dek.encryption_state = 3


-- Cleanup certificates after last object using is gone
USE AdventureWorks2012
GO
ALTER DATABASE AdventureWorks2012  
SET ENCRYPTION OFF;  
GO
WAITFOR DELAY '00:00:10'
GO
DROP DATABASE ENCRYPTION KEY
GO
USE master
go
DROP CERTIFICATE TDEDemoCertforMI
go
--DROP MASTER KEY
--go

