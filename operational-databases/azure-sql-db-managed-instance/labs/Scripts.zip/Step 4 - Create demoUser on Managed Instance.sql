/*Execute this script both on local SQL Server and SQL MI!*/

IF EXISTS (SELECT * FROM sys.server_principals WHERE name = 'demoUser')
	DROP LOGIN demoUser;

CREATE LOGIN demoUser with password = '@BuildHands0nLab2018';
	ALTER SERVER ROLE sysadmin add member demoUser;

