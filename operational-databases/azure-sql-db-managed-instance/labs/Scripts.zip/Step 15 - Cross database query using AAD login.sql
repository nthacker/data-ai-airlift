--Get objectID from AAD in the portal. TO do this sign-in to portal click AAD->users, search for your alias@microsoft.com. Then copy the object id here. Then convert this to SID.
SELECT CAST(CAST('d9556ceb-8ab8-4d61-bb8a-c175424f605e' AS UNIQUEIDENTIFIER) AS VARBINARY(16)) SID 
GO 
--Create aad login from SID
CREATE LOGIN [ajayj@microsoft.com] FROM EXTERNAL PROVIDER 
  WITH SID = 0xEB6C55D9B88A614DBB8AC175424F605E, TYPE=E 
GO 
 
--To check the newly added login, execute the following T-SQL command: 
 
SELECT *   
FROM sys.server_principals;   
GO 
--Make login as sysadmin
ALTER SERVER ROLE sysadmin ADD MEMBER [ajayj@microsoft.com] 
GO 
--next login using this account from a different SSMS client using Universal with MFA
--Run cross-db query from master
USE MASTER
GO
SELECT * FROM [Adventureworks2012].[HumanResources].[Department]
