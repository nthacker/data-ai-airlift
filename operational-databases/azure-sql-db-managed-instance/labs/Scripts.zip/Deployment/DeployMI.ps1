﻿$subscriptionId = '<subscriptionid>'
$instanceName = '<managed instance name>'
$userId = '<sql user>'
$password = '<password>'
$resourcegroup = '<rgname>'
$sku = 'GP_Gen5'

#Connect-AzureRmAccount

Select-AzureRmSubscription -SubscriptionId $subscriptionId

$secpasswd = ConvertTo-SecureString $password -AsPlainText -Force

New-AzureRmResourceGroupDeployment -Name sqldbmi -instancename $instanceName -sku $sku -pwd $secpasswd -ResourceGroupName $resourcegroup -TemplateFile 'C:\Demo Materials\Scripts\Deployment\MI Deployment.json'