$subscriptionId = '<subscriptionid>'
$instanceName = '<managed instance name>'
$userId = '<sql user>'
$password = '<password>'
$resourcegroup = '<rgname>'
$vnet = '<mi vnet>'
$subnet = '<mi subnet>'
$location = '<location>'

# Set the subscription
az account set --subscription $subscriptionId

#List all MI instances in subscription
az sql mi list

#View properties of an instance
az sql mi show -n $instanceName -g $resourcegroup

#Create MI instance
az sql mi create -n $instanceName -u $userId -p $password  -g $resourcegroup -l $location --vnet-name $vnet --subnet $subnet -c 8 --storage 32 --tier GeneralPurpose --license-type LicenseIncluded --family Gen4
