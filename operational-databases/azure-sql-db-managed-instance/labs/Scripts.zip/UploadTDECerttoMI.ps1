﻿$scriptUrlBase = 'https://raw.githubusercontent.com/Microsoft/sql-server-samples/master/samples/manage/azure-sql-db-managed-instance/upload-tde-certificate'

$parameters = @{
    subscriptionId = '<subscriptionid>'
    resourceGroupName = '<rgname>'
    managedInstanceName  = '<managed instance name>'
    publicKeyFile  = '<file path>\TDEDemoCertforMI.cer'
    privateKeyFile  = '<file path\TDEDemoCertforMI.pvk'
    password  = '<password>'
    }

Invoke-Command -ScriptBlock ([Scriptblock]::Create((iwr ($scriptUrlBase+'/uploadTDECertificate.ps1?t='+ [DateTime]::Now.Ticks)).Content)) -ArgumentList $parameters