/*Execute this script on SQL MI!*/

USE master;
EXEC sp_configure 'clr enabled', 0;
GO
RECONFIGURE;

/* Check if the settings changed */
SELECT name, value from sys.configurations
WHERE NAME like 'clr%';

GO

use TenantDataDB;
GO

SELECT a.name as AssemblyName, permission_set_desc, assembly_class, 
assembly_method FROM sys.assemblies a
JOIN sys.assembly_modules am 
ON a.assembly_id = am.assembly_id
