CREATE CREDENTIAL [<Azure Blob URL, , >/audit] 
WITH IDENTITY='SHARED ACCESS SIGNATURE',
SECRET = '<SAS secret, , >'
GO

-- Create server audit
CREATE SERVER AUDIT [SqlAuditing_Audit] TO URL ( PATH ='<Azure Blob URL, , >/audit') 
GO 

-- Create server audit specification
CREATE SERVER AUDIT SPECIFICATION [SqlAuditing_ServerAuditSpec]
FOR SERVER AUDIT [SqlAuditing_Audit]
ADD (SCHEMA_OBJECT_CHANGE_GROUP),
ADD (SERVER_PRINCIPAL_CHANGE_GROUP)         -- Will audit statements like: "CREATE TABLE t1", etc.
WITH (STATE=ON);
GO

-- Need to set it to OFF for ALTER
--ALTER SERVER AUDIT [SqlAuditing_Audit] 
--WITH (STATE=OFF);
--GO
-ALTER SERVER AUDIT SPECIFICATION [SqlAuditing_ServerAuditSpec]
-FOR SERVER AUDIT [SqlAuditing_Audit]
-ADD (SERVER_PRINCIPAL_CHANGE_GROUP)         -- Will audit statements like: "CREATE TABLE t1", etc.
-WITH (STATE=ON);
-GO





-- Create database audit specification
CREATE DATABASE AUDIT SPECIFICATION [SqlAuditing_DatabaseAuditSpec]
FOR SERVER AUDIT [SqlAuditing_Audit]
       ADD (SELECT ON schema::dbo BY [public]), -- Will audit statements like: "SELECT * FROM dbo.t1", etc.
       ADD (INSERT ON schema::dbo BY [public]) 
WITH (STATE=ON);
GO


-- Enable the server audit
ALTER SERVER AUDIT [SqlAuditing_Audit] 
WITH (STATE=ON);
GO


-- Run some queries to be audited

CREATE TABLE t1 (c1 INT NULL)
INSERT INTO t1 VALUES (1)
SELECT * FROM dbo.t1

DROP TABLE t1


-- Read audit logs
SELECT * FROM sys.fn_get_audit_file((select audit_file_path from sys.dm_server_audit_status where name= 'SqlAuditing_Audit'), default, default)
GO

-- Cleanup

ALTER SERVER AUDIT [SqlAuditing_Audit] 
WITH (STATE=OFF);
GO

ALTER SERVER AUDIT SPECIFICATION [SqlAuditing_ServerAuditSpec]
WITH (STATE=OFF);
GO

ALTER DATABASE AUDIT SPECIFICATION [SqlAuditing_DatabaseAuditSpec]
WITH (STATE=OFF);
GO

DROP SERVER AUDIT SPECIFICATION [SqlAuditing_ServerAuditSpec]
GO

DROP DATABASE AUDIT SPECIFICATION [SqlAuditing_DatabaseAuditSpec]
GO

DROP SERVER AUDIT [SqlAuditing_Audit] -- needs correction
GO
  
DROP CREDENTIAL [<Azure Blob URL, , >/audit] 
GO




--CREATE BLOB
--GET THE KEY
--CREATE CONTAINER
--Get the URL and SAS key