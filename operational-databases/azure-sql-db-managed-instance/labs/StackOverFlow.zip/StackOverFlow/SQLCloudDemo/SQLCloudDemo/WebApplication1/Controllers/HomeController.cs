﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using System.Data.SqlClient;
using System.Data;
using System.Text.RegularExpressions;
using Dapper;
using Microsoft.Extensions.Configuration;
using WebApplication1.Models;

namespace WebApplication1.Controllers
{
    public class HomeController : Controller
    {
        IConfiguration config;

        public HomeController(IConfiguration config)
        {
            this.config = config;
        }

        public IActionResult Index()
        {
            var questionsViewModel = new QuestionsViewModel();
            var postList = new List<Question>();
            questionsViewModel.Questions = postList;
            
            using (var connection = GetOpenConnection())
            {
                var command = new SqlCommand(
@"SELECT top 15 p.Title, p.AnswerCount, pmd.ViewCount, p.Score, p.Body, 
cast(p.AcceptedAnswerId as bit) as hasacceptedAnswer, p.CreationDate, 
u.Id, u.DisplayName, u.ProfileImageUrl, u.Reputation, u.BronzeBadges, u.SilverBadges, u.GoldBadges, 
p.Tags, p.Id 
From Posts p Join PostMetadata pmd on p.Id = pmd.PostId Left Join Users u on p.OwnerUserId = u.Id 
Where p.Title is not null
and Tags not like '%amazon%'  
order by AnswerCount desc", connection);

                questionsViewModel.SQLVersion = connection.ExecuteScalar<string>("exec dbo.GetSQLVersion");
                questionsViewModel.TotalQuestionCount = connection.ExecuteScalar<int>("select count(*) from Posts");

                using (var reader = command.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        questionsViewModel.Questions.Add(new Question() {
                            Title = reader[0].ToString(),
                            AnswerCount = (reader[1].ToString().Length > 0) ? reader[1].ToString() : "0",
                            ViewCount = (reader[2].ToString().Length > 0) ? reader[2].ToString() : "0",
                            VoteCount = (reader[3].ToString().Length > 0) ? reader[3].ToString() : "0",
                            Body = getExcerpt(reader[4].ToString()),
                            AcceptedAnswer = reader[5].ToString(),
                            AskedDate = (DateTime)reader[6],
                            User = new QuestionUser()
                            {
                                UserId = reader[7].ToString(),
                                Username = reader[8].ToString(),
                                AvatarURL = string.IsNullOrWhiteSpace(reader[9].ToString()) ? $"https://www.gravatar.com/avatar/{reader[8].GetHashCode()}?s=32&d=identicon&r=PG" : reader[9].ToString(),
                                ReputationScore = reader[10].ToString(),
                                BronzeMedals = reader[11].ToString(),
                                SilverMedals = reader[12].ToString(),
                                GoldMedals = reader[13].ToString()
                            },
                            Tags = reader[14].ToString(),
                            Id = reader[15].ToString()
                        });
                    }
                }
            }

            return View(questionsViewModel);
        }

        private string getExcerpt(string text)
        {

            const int maxChars = 200;
            var tagsToClear = new[] {"img", "code", "pre"};

            // strip newlines so that regex just has to work on a single line
            var excerpt = text.Replace("\r", string.Empty).Replace("\n", string.Empty);

            // clear contents of selected tags
            foreach (var tag in tagsToClear)
            {
                excerpt = Regex.Replace(excerpt, $"<{tag}>(.*?)</{tag}>", "test");
            }

            // remove all tags
            excerpt = Regex.Replace(excerpt, "<.*?>", string.Empty);

            // get first N chars if the excerpt is still long after stripping tags
            if (excerpt.Length > maxChars)
            {
                int rightIndex;
                for (rightIndex = maxChars - 1; rightIndex > 0; rightIndex--)
                {
                    if (excerpt[rightIndex] == ' ')
                    {
                        break;
                    }
                }

                excerpt = excerpt.Substring(0, rightIndex + 1) + "...";
            }

            return excerpt;
        }

        public IActionResult Questions(int id)
        {
            QuestionViewModel questionViewModel = new QuestionViewModel();
            
            using (var conn = GetOpenConnection())
            {
                questionViewModel.SQLVersion = conn.ExecuteScalar<string>("exec dbo.GetSQLVersion");
                
                var questionSql = @"
select p.Id, p.CreationDate, p.Title, p.Body, p.Score, p.Tags, p.AcceptedAnswerId,
u.Id as UserId, u.DisplayName, u.ProfileImageUrl, u.Reputation, u.BronzeBadges, u.SilverBadges, u.GoldBadges 
from Posts p 
inner join Users u on p.OwnerUserId = u.Id 
where p.Id=@id";
                questionViewModel.Question = conn.Query(questionSql, new {id})
                    ?.Select(data => new Question
                    {
                        Id = data.Id?.ToString(),
                        AskedDate = data.CreationDate,
                        Title = data.Title,
                        Body = data.Body,
                        Score = data.Score,
                        Tags = data.Tags,
                        AcceptedAnswerId = data.AcceptedAnswerId,
                        User = new QuestionUser
                        {
                            UserId = data.UserId?.ToString(),
                            Username = data.DisplayName,
                            AvatarURL = string.IsNullOrWhiteSpace(data.ProfileImageUrl) ? $"https://www.gravatar.com/avatar/{data.DisplayName.GetHashCode()}?s=32&d=identicon&r=PG" : data.ProfileImageUrl,
                            ReputationScore = data.Reputation?.ToString(),
                            BronzeMedals = data.BronzeBadges?.ToString(),
                            SilverMedals = data.SilverBadges?.ToString(),
                            GoldMedals = data.GoldBadges?.ToString()
                        }
                    }).FirstOrDefault();

                var answersSql = @"
select
answer.*,
u.Id as UserId, u.DisplayName, u.ProfileImageUrl, u.Reputation, u.BronzeBadges, u.SilverBadges, u.GoldBadges 
from Posts answer
inner join Users u on answer.OwnerUserId = u.Id
where answer.ParentId = @id
order by Score desc
";
                var answers = conn.Query(answersSql, new {id}).ToList();
                foreach (var ans in answers)
                {
                    ans.ProfileImageUrl = string.IsNullOrWhiteSpace(ans.ProfileImageUrl)
                        ? $"https://www.gravatar.com/avatar/{ans.DisplayName.GetHashCode()}?s=32&d=identicon&r=PG"
                        : ans.ProfileImageUrl;
                }
                questionViewModel.Answers = answers;
                
                var commentsSql = @"
select p.Id as PostId, 
c.*, 
u.Id as UserId, u.DisplayName as Username, u.Reputation
from Posts p 
inner join PostComments c on p.Id = c.PostId
inner join Users u on c.UserId = u.Id
where p.Id in @ids
and c.DeletionDate is null
order by c.CreationDate
";
                var postIds = new List<string>(new[] {id.ToString()});
                postIds.AddRange(answers.Select(a => ((int)a.Id).ToString()));
                var comments = conn.Query(commentsSql, new {ids = postIds});

                var commentsMap = new Dictionary<string, List<dynamic>>();
                foreach (var comment in comments)
                {
                    var postId = comment.PostId.ToString();
                    if (!commentsMap.ContainsKey(postId))
                        commentsMap[postId] = new List<dynamic>();

                    comment.Text = Regex.Replace(comment.Text, @"\[([^]]*)\]\(([^\s^\)]*)[\s\)]", @"<a href='$2'>$1</a>");
                    commentsMap[postId].Add(comment);
                }
                questionViewModel.Comments = commentsMap;

                return View(questionViewModel);
            }
        }

        public IActionResult Details()
        {
            ViewData["Message"] = "Your contact page.";

            return View();
        }

        public IActionResult Error()
        {
            return View();
        }

        private SqlConnection GetOpenConnection()
        {
            var constr = config["ConnectionStrings:DefaultConnection"];
            var conn = new SqlConnection(constr);
            conn.Open();
            return conn;
        }
    }
}
