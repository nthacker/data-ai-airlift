﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace WebApplication1.Models
{
    public class QuestionViewModel : BaseViewModel
    {
        public Question Question { get; set; }
        public Dictionary<string,List<dynamic>> Comments { get; set; }
        public IEnumerable<dynamic> Answers { get;set; }
    }
}
