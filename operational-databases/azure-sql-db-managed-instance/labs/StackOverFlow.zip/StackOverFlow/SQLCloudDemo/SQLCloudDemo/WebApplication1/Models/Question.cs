﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace WebApplication1.Models
{
    public class Question
    {
        public string Id { get; set; }
        public string Title { get; set; }
        public string AnswerCount { get; set; }
        public string ViewCount { get; set; }
        public string VoteCount { get; set; }
        public string Body { get; set; }
        public string AcceptedAnswer { get; set; }
        public DateTime AskedDate { get; set; }
        public int? Score { get; set; }
        public DateTime? LastActivityDate { get; set; }
        public int? AcceptedAnswerId { get; set; }
        
        public string AnswerCSS {
            get
            {
                if(AcceptedAnswer == "True")
                {
                    return "answered-accepted";
                }
                else if (this.AnswerCount != "0")
                {
                    return "answered";
                }

                return "unanswered";
            }
        }

        public QuestionUser User { get; set; }
        public string Tags { get; set; }

        public string[] TagsList
        {
            get
            {
                if (string.IsNullOrWhiteSpace(Tags))
                    return new string[0];

                return Tags.Split('|')
                    .Select(tag => tag.Trim())
                    .Where(tag => !string.IsNullOrWhiteSpace(tag))
                    .ToArray();
            }
        }
    }
}
