﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace WebApplication1.Models
{
    public class QuestionUser
    {
        public string UserId { get; set; }
        public string Username { get; set; }
        public string AvatarURL{ get; set; }
        public string ReputationScore { get; set; }
        public string GoldMedals { get; set; }
        public string SilverMedals { get; set; }
        public string BronzeMedals { get; set; }

        public string FormattedReputationScore => int.TryParse(ReputationScore, out var score) ? $"{score:n0}" : ReputationScore;
    }
}
