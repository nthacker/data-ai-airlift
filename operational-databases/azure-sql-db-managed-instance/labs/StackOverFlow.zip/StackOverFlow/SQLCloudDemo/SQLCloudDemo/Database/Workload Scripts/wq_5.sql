CREATE PROCEDURE UserHistory3
AS
declare @creationdate datetime
set @creationdate = '2017-02-28 16:47:00'
declare @i int
set @i = 1

while @i < 50
begin
declare @userhistorytypeid  int
set @userhistorytypeid = 1

while @userhistorytypeid < 100
begin
SELECT userid, applicationid FROM userhistory WHERE ISNULL(ApplicationID, 2) = 1366

SET @userhistorytypeid = @userhistorytypeid+1
end
set @i = @i + 1
end