CREATE PROCEDURE UserHistory2
AS
declare @i int
set @i = 1

while @i < 100
begin
declare @userhistorytypeid  int
set @userhistorytypeid = 1

while @userhistorytypeid < 100
begin
select count(*), u.displayname
from users u inner join userhistory h
on u.id = h.userid
where silverbadges > 0
group by u.displayname
SET @userhistorytypeid = @userhistorytypeid+1
end
set @i = @i + 1
end